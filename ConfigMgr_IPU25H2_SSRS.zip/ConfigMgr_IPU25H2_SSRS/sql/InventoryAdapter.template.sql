/* TEMPLATE ONLY - not ready to execute.
   Replace dbo.<ER_INVENTERINGSVY> and EVERY source column with real SQL names.
   SQL inventory view names differ from WQL names (often v_GS_* and suffix 0).
   Paste this SELECT inside InventoryRaw in Inventory.sql AND the RDL dataset.
   Preserve the output aliases/types. Normalize dates to UTC and values to:
     CompatStatus / ReadinessStatus: Passed, Blocked, Error, Unknown
     PreCacheStatus: Pending, Complete, Blocked, Failed
     PostCheckStatus: Passed, Failed, Unknown
   Mapping numeric codes to these states is a local decision, not provided
   automatically. Raw Check Readiness failure != generic transport error.
   Emit one coherent current row per ResourceID and TargetRelease.
   Unsupported result fields may remain typed NULL; do not invent results. */
SELECT
    ResourceID,
    TRY_CONVERT(datetime2, <KONTROLLTID_UTC>) AS AssessmentTime,
    CONVERT(nvarchar(32), <MALVERSION>) AS TargetRelease,
    CONVERT(nvarchar(64), <PRECACHE_REVISION>) AS PreCacheRevision,
    CONVERT(nvarchar(32), <NORMALISERAD_COMPATSTATUS>) AS CompatStatus,
    CONVERT(nvarchar(32), <NORMALISERAD_READINESSSTATUS>) AS ReadinessStatus,
    CONVERT(nvarchar(32), <NORMALISERAD_PRECACHESTATUS>) AS PreCacheStatus,
    CONVERT(nvarchar(64), <COMPAT_RETURKOD>) AS CompatExitCode,
    CAST(NULL AS datetime2) AS IPUResultTime,
    CAST(NULL AS nvarchar(32)) AS PostCheckStatus,
    CAST(NULL AS bit) AS SetupRollback
FROM dbo.<ER_INVENTERINGSVY>;
