/* Dataset StepHistory. All observed steps; a nonzero exit code is NOT
   automatically a failure (for example 3010 or compat-scan success).
   No attempt boundaries are invented. Uses authorized device + advertisement. */
IF @DaysBack < 1 OR @DaysBack > 3650
    THROW 50003, 'DaysBack must be between 1 and 3650.', 1;

SELECT TOP (5000)
    s.Netbios_Name0 AS ComputerName,t.ResourceID,t.AdvertisementID,
    a.AdvertisementName,t.ExecutionTime,t.Step,t.ActionName,t.GroupName,
    CONVERT(nvarchar(64),t.ExitCode) AS ExitCode,
    CONVERT(varchar(10),CONVERT(binary(4),TRY_CONVERT(bigint,t.ExitCode)),1) AS ExitCodeHex,
    t.LastStatusMessageID,t.LastStatusMessageIDName AS MessageText,
    LEFT(CONVERT(nvarchar(max),t.ActionOutput),4000) AS ActionOutput
FROM dbo.v_TaskExecutionStatus t
INNER JOIN dbo.fn_rbac_R_System(@UserSIDs) s ON s.ResourceID=t.ResourceID
INNER JOIN dbo.fn_rbac_Advertisement(@UserSIDs) a ON a.AdvertisementID=t.AdvertisementID
WHERE t.ResourceID=@ResourceID
  AND t.AdvertisementID=@AdvertisementID
  AND t.ExecutionTime>=DATEADD(day,-@DaysBack,SYSUTCDATETIME())
ORDER BY t.ExecutionTime DESC,t.Step DESC,t.LastStatusMessageID DESC;
