/* Dataset InventoryStatus. DEFAULT: typed empty adapter, so the base report
   runs without any custom inventory class. Replace ONLY InventoryRaw below.
   These rows are displayed separately from deployment status, with timestamps.
   Never equate missing inventory with Passed or TS success with Complete. */
;WITH InventoryRaw AS (
    -- ADAPTER_BEGIN
    SELECT CAST(NULL AS int) AS ResourceID,
        CAST(NULL AS datetime2) AS AssessmentTime,
        CAST(NULL AS nvarchar(32)) AS TargetRelease,
        CAST(NULL AS nvarchar(64)) AS PreCacheRevision,
        CAST(NULL AS nvarchar(32)) AS CompatStatus,
        CAST(NULL AS nvarchar(32)) AS ReadinessStatus,
        CAST(NULL AS nvarchar(32)) AS PreCacheStatus,
        CAST(NULL AS nvarchar(64)) AS CompatExitCode,
        CAST(NULL AS datetime2) AS IPUResultTime,
        CAST(NULL AS nvarchar(32)) AS PostCheckStatus,
        CAST(NULL AS bit) AS SetupRollback
    WHERE 1=0
    -- ADAPTER_END
), Marked AS (
    SELECT i.*,COUNT(*) OVER (PARTITION BY ResourceID) AS InventoryRows,
        ROW_NUMBER() OVER (PARTITION BY ResourceID
          ORDER BY AssessmentTime DESC,IPUResultTime DESC) AS rn
    FROM InventoryRaw i WHERE i.TargetRelease='25H2'
)
SELECT i.ResourceID,s.Netbios_Name0 AS ComputerName,
    CASE WHEN RIGHT(s.Netbios_Name0,1) LIKE '[0-9]'
         THEN RIGHT(s.Netbios_Name0,1) ELSE 'Other' END AS Ring,
    i.AssessmentTime,i.PreCacheRevision,i.CompatStatus,i.ReadinessStatus,
    i.PreCacheStatus,i.CompatExitCode,i.IPUResultTime,i.PostCheckStatus,i.SetupRollback,
    CASE WHEN i.SetupRollback=1 THEN N'Ja' WHEN i.SetupRollback=0
         THEN N'Nej' ELSE N'Okänt' END AS RollbackText,
    CASE WHEN i.InventoryRows>1 THEN N'Flera poster: korrigera mapping; visad rad är inte en verifierad gemensam körning.'
         WHEN i.AssessmentTime IS NULL THEN N'PreCache-tid saknas.'
         WHEN i.AssessmentTime>SYSUTCDATETIME() THEN N'Tid i framtiden: kontrollera tidszon.'
         WHEN i.AssessmentTime<DATEADD(hour,-@InventoryMaxAgeHours,SYSUTCDATETIME())
           THEN N'Gammal PreCache-inventering. Status kan ha ändrats.'
         ELSE N'Inventerad ögonblicksbild. Jämför tid/revision med senaste TS-körning.' END AS DataNote
FROM Marked i
INNER JOIN dbo.fn_rbac_R_System(@UserSIDs) s ON s.ResourceID=i.ResourceID
WHERE i.rn=1
  AND EXISTS (SELECT 1 FROM dbo.v_FullCollectionMembership f
      INNER JOIN dbo.fn_rbac_Collection(@UserSIDs) c ON c.CollectionID=f.CollectionID
      WHERE f.ResourceID=i.ResourceID AND f.CollectionID=@CollectionID)
  AND (@Ring='ALL' OR RIGHT(s.Netbios_Name0,1)=@Ring
       OR (@Ring='Other' AND RIGHT(s.Netbios_Name0,1) NOT LIKE '[0-9]'))
ORDER BY s.Netbios_Name0;
