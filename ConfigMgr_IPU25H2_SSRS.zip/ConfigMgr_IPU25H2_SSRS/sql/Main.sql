/* SSRS dataset NativeStatus. Read-only; requires SSRS multivalue parameters.
   @UserSIDs is populated through ConfigMgr's normal RBAC parameter chain.
   Latest status is selected BEFORE filtering errors. No historical date filter.
   This is latest reported deployment status, NOT an exact per-attempt ledger. */
IF @StaleHours < 1 OR @StaleHours > 8760
    THROW 50001, 'StaleHours must be between 1 and 8760.', 1;
IF EXISTS (
    SELECT 1 FROM dbo.fn_rbac_Advertisement(@UserSIDs) a
    WHERE a.AdvertisementID IN (@IPUDeploymentIDs)
      AND a.AdvertisementID IN (@PreCacheDeploymentIDs)
)
    THROW 50002, 'The same deployment cannot be both PreCache and IPU.', 1;

;WITH ScopeDevices AS (
    SELECT DISTINCT s.ResourceID, s.Netbios_Name0 AS ComputerName,
        CASE WHEN RIGHT(s.Netbios_Name0,1) LIKE '[0-9]'
             THEN RIGHT(s.Netbios_Name0,1) ELSE 'Other' END AS Ring
    FROM dbo.fn_rbac_R_System(@UserSIDs) s
    INNER JOIN dbo.v_FullCollectionMembership f ON f.ResourceID=s.ResourceID
    INNER JOIN dbo.fn_rbac_Collection(@UserSIDs) c ON c.CollectionID=f.CollectionID
    WHERE f.CollectionID=@CollectionID
), SelectedDeployments AS (
    SELECT a.AdvertisementID, a.AdvertisementName,
        CASE WHEN a.AdvertisementID IN (@IPUDeploymentIDs)
             THEN 'IPU' ELSE 'PreCache' END AS Phase
    FROM dbo.fn_rbac_Advertisement(@UserSIDs) a
    WHERE a.AdvertisementID IN (@IPUDeploymentIDs)
       OR a.AdvertisementID IN (@PreCacheDeploymentIDs)
), Assignments AS (
    SELECT DISTINCT x.ResourceID,a.Phase
    FROM dbo.v_CurrentAdvertisementAssignments x
    INNER JOIN SelectedDeployments a ON a.AdvertisementID=x.AdvertisementID
    INNER JOIN ScopeDevices s ON s.ResourceID=x.ResourceID
), Events AS (
    SELECT st.ResourceID,a.Phase,a.AdvertisementID,a.AdvertisementName,
        st.LastState,st.LastStateName,st.LastStatusTime,
        st.LastAcceptanceState,st.LastAcceptanceStatusTime,
        CONVERT(nvarchar(1024),st.LastExecutionResult) AS LastExecutionResult,
        CASE WHEN st.LastAcceptanceState IN (2,3)
               AND (st.LastStatusTime IS NULL
                    OR st.LastAcceptanceStatusTime>st.LastStatusTime)
             THEN st.LastAcceptanceStatusTime ELSE st.LastStatusTime END AS EventTime
    FROM dbo.v_ClientAdvertisementStatus st
    INNER JOIN SelectedDeployments a ON a.AdvertisementID=st.AdvertisementID
    INNER JOIN ScopeDevices s ON s.ResourceID=st.ResourceID
), Ranked AS (
    SELECT e.*,
        ROW_NUMBER() OVER (PARTITION BY ResourceID,Phase
            ORDER BY EventTime DESC,
              CASE WHEN LastState=11 THEN 0 ELSE 1 END,
              AdvertisementID DESC) AS rn,
        COUNT(*) OVER (PARTITION BY ResourceID,Phase,EventTime) AS SameTimeRows
    FROM Events e
    WHERE EventTime IS NOT NULL
), Snapshot AS (
    SELECT s.ResourceID,s.ComputerName,s.Ring,p.Phase,
        r.AdvertisementID,r.AdvertisementName,r.LastState,r.LastStateName,
        r.EventTime,r.LastStatusTime,r.LastExecutionResult,
        COALESCE(r.SameTimeRows,0) AS SameTimeRows,
        CASE WHEN a.ResourceID IS NULL THEN 0 ELSE 1 END AS CurrentlyAssigned,
        CASE WHEN r.LastAcceptanceState IN (2,3)
               AND (r.LastStatusTime IS NULL
                    OR r.LastAcceptanceStatusTime>r.LastStatusTime)
             THEN r.LastAcceptanceState END AS AcceptanceProblem,
        CASE WHEN r.LastStatusTime < DATEADD(hour,-@StaleHours,SYSUTCDATETIME())
             THEN 1 ELSE 0 END AS OldStatus,
        os.BuildNumber0 AS OSBuild
    FROM ScopeDevices s
    CROSS JOIN (SELECT DISTINCT Phase FROM SelectedDeployments) p
    LEFT JOIN Ranked r ON r.ResourceID=s.ResourceID AND r.Phase=p.Phase AND r.rn=1
    LEFT JOIN Assignments a ON a.ResourceID=s.ResourceID AND a.Phase=p.Phase
    OUTER APPLY (
        SELECT TOP (1) o.BuildNumber0
        FROM dbo.v_GS_OPERATING_SYSTEM o WHERE o.ResourceID=s.ResourceID
        ORDER BY o.TimeStamp DESC
    ) os
    WHERE @Ring='ALL' OR s.Ring=@Ring
), Classified AS (
    SELECT s.*,
    /* CLASSIFICATION_BEGIN: also exercised by local fixture tests. */
    CASE
        WHEN SameTimeRows>1 THEN 'AMBIGUOUS'
        WHEN AcceptanceProblem=2 THEN 'REJECTED'
        WHEN AcceptanceProblem=3 THEN 'EXPIRED'
        WHEN LastState=11 THEN 'FAILED'
        WHEN LastState=7 THEN 'CANCELED'
        WHEN LastState=4 THEN 'NOT_RERUN'
        WHEN LastState IN (5,6,8,9,10,12) AND OldStatus=1 THEN 'STALE'
        WHEN LastState=13 THEN 'TS_SUCCEEDED'
        WHEN LastState IN (5,6,8,9,10,12) THEN 'IN_PROGRESS'
        WHEN CurrentlyAssigned=1 THEN 'NO_STATUS'
        WHEN LastState IS NULL OR LastState=0 THEN 'NOT_ASSIGNED'
        ELSE 'REVIEW'
    END AS StatusCode
    /* CLASSIFICATION_END */
    FROM Snapshot s
), Labelled AS (
    SELECT c.*,
        CASE StatusCode
          WHEN 'AMBIGUOUS' THEN N'Samtidiga statusar - granska'
          WHEN 'REJECTED' THEN N'Deployment avvisad'
          WHEN 'EXPIRED' THEN N'Deployment utgången'
          WHEN 'FAILED' THEN CASE WHEN Phase='IPU' AND OSBuild='26200'
                                  THEN N'IPU-fel; 25H2 inventerat'
                                  ELSE N'TS misslyckad' END
          WHEN 'CANCELED' THEN N'Avbruten'
          WHEN 'NOT_RERUN' THEN N'Återkörs inte'
          WHEN 'STALE' THEN N'Gammal pågående/väntande status'
          WHEN 'TS_SUCCEEDED' THEN N'TS lyckad; efterkontroll separat'
          WHEN 'IN_PROGRESS' THEN N'Pågår / väntar'
          WHEN 'NO_STATUS' THEN N'Tilldelad; rapport saknas'
          WHEN 'NOT_ASSIGNED' THEN N'Ej tilldelad / ingen rapport'
          ELSE N'Granska status' END AS StatusLabel,
        CASE WHEN StatusCode IN ('TS_SUCCEEDED','IN_PROGRESS','NOT_ASSIGNED')
             THEN 0 ELSE 1 END AS IsIssue,
        CASE StatusCode
          WHEN 'FAILED' THEN CASE WHEN Phase='IPU' AND OSBuild='26200'
            THEN N'Utred eftersteg. Kör riktad reparation, inte full IPU automatiskt.'
            ELSE N'Öppna steghistorik. Kontrollera smsts.log och vid Setup-fel SetupDiag.' END
          WHEN 'NO_STATUS' THEN N'Kontrollera online/policy/deadline. Detta är inte bevis på ett körningsfel.'
          WHEN 'STALE' THEN N'Kontrollera klientkontakt och senaste aktivitet. Tidsgränsen bevisar inte ett avbrott.'
          WHEN 'REJECTED' THEN N'Kontrollera tillämplighet och mottagen policy.'
          WHEN 'NOT_RERUN' THEN N'Kontrollera rerun-inställning och godkännande för återförsök.'
          WHEN 'AMBIGUOUS' THEN N'Flera deploymenter har samma senaste tid. Kontrollera dem före åtgärd.'
          WHEN 'TS_SUCCEEDED' THEN N'Kontrollera OS och efterkontroll innan migrationen räknas som Complete.'
          ELSE N'Kontrollera deployment och klientlogg vid behov.' END AS NextAction
    FROM Classified c
)
SELECT l.*,
    t.ActionName AS LatestStepName,t.ExecutionTime AS LatestStepTime,
    CONVERT(nvarchar(64),t.ExitCode) AS LatestStepCode,
    CONVERT(varchar(10),CONVERT(binary(4),TRY_CONVERT(bigint,t.ExitCode)),1) AS LatestStepHex,
    t.LastStatusMessageID AS LatestStepMessageID
FROM Labelled l
OUTER APPLY (
    SELECT TOP (1) ts.ActionName,ts.ExecutionTime,ts.ExitCode,ts.LastStatusMessageID
    FROM dbo.v_TaskExecutionStatus ts
    WHERE ts.ResourceID=l.ResourceID AND ts.AdvertisementID=l.AdvertisementID
      AND ts.ExecutionTime<=COALESCE(l.EventTime,SYSUTCDATETIME())
    ORDER BY ts.ExecutionTime DESC,ts.Step DESC,ts.LastStatusMessageID DESC
) t
WHERE @OnlyIssues=0 OR l.IsIssue=1
ORDER BY CASE WHEN l.StatusCode='FAILED' THEN 0 ELSE 1 END,
         l.EventTime DESC,l.ComputerName,l.Phase;
