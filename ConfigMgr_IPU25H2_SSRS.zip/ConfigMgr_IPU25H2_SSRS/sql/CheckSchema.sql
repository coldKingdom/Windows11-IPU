/* Run read-only in the CM_<sitecode> database before importing the report.
   First result must be empty. Subsequent results help verify adapters/RBAC.
   No database objects are created or changed. */
WITH Expected(ObjectName,ColumnName) AS (
 SELECT * FROM (VALUES
 ('v_ClientAdvertisementStatus','ResourceID'),
 ('v_ClientAdvertisementStatus','AdvertisementID'),
 ('v_ClientAdvertisementStatus','LastState'),
 ('v_ClientAdvertisementStatus','LastStateName'),
 ('v_ClientAdvertisementStatus','LastStatusTime'),
 ('v_ClientAdvertisementStatus','LastAcceptanceState'),
 ('v_ClientAdvertisementStatus','LastAcceptanceStatusTime'),
 ('v_ClientAdvertisementStatus','LastExecutionResult'),
 ('v_CurrentAdvertisementAssignments','ResourceID'),
 ('v_CurrentAdvertisementAssignments','AdvertisementID'),
 ('v_TaskExecutionStatus','ResourceID'),
 ('v_TaskExecutionStatus','AdvertisementID'),
 ('v_TaskExecutionStatus','ExecutionTime'),
 ('v_TaskExecutionStatus','Step'),
 ('v_TaskExecutionStatus','ActionName'),
 ('v_TaskExecutionStatus','GroupName'),
 ('v_TaskExecutionStatus','ExitCode'),
 ('v_TaskExecutionStatus','LastStatusMessageID'),
 ('v_TaskExecutionStatus','LastStatusMessageIDName'),
 ('v_TaskExecutionStatus','ActionOutput'),
 ('v_GS_OPERATING_SYSTEM','ResourceID'),
 ('v_GS_OPERATING_SYSTEM','TimeStamp'),
 ('v_GS_OPERATING_SYSTEM','BuildNumber0'),
 ('v_FullCollectionMembership','ResourceID'),
 ('v_FullCollectionMembership','CollectionID')
 ) x(ObjectName,ColumnName)
)
SELECT e.ObjectName,e.ColumnName,N'MISSING OR NOT VISIBLE' AS Result
FROM Expected e
WHERE NOT EXISTS (SELECT 1 FROM sys.columns c
 WHERE c.object_id=OBJECT_ID('dbo.'+e.ObjectName) AND c.name=e.ColumnName);

SELECT x.ObjectName,
 CASE WHEN OBJECT_ID('dbo.'+x.ObjectName) IS NULL THEN 'MISSING OR NOT VISIBLE'
      ELSE 'FOUND' END AS Result
FROM (VALUES ('fn_rbac_R_System'),('fn_rbac_Collection'),
 ('fn_rbac_Advertisement'),('fn_rbac_GetAdminIDsfromUserSIDs'),
 ('v_TaskSequencePackage')) x(ObjectName);

SELECT o.name AS ObjectName,c.name AS ColumnName,t.name AS DataType
FROM sys.objects o INNER JOIN sys.columns c ON c.object_id=o.object_id
INNER JOIN sys.types t ON t.user_type_id=c.user_type_id
WHERE o.name IN ('fn_rbac_R_System','fn_rbac_Collection','fn_rbac_Advertisement')
ORDER BY o.name,c.column_id;

-- Candidate custom-inventory SQL views; verify actual mapping in Resource Explorer.
SELECT v.name AS ViewName,c.name AS ColumnName,t.name AS DataType
FROM sys.views v INNER JOIN sys.columns c ON c.object_id=v.object_id
INNER JOIN sys.types t ON t.user_type_id=c.user_type_id
WHERE c.name LIKE '%CompatStatus%' OR c.name LIKE '%ReadinessStatus%'
ORDER BY v.name,c.column_id;
