# ConfigMgr IPU 25H2 - SSRS-rapportpaket

Version 1.0 · 2026-09-28 · Windows 10 22H2 till Windows 11 25H2

Paketet innehåller två rapportdefinitioner för SSRS 2016 eller senare, SQL-underlag och en separat mall för era inventerade PreCache-resultat. SQL läser ConfigMgrs rapportvyer; det skapar eller ändrar inga databasobjekt.

## Det som fungerar efter anslutning

**IPU25H2_Feloversikt.rdl** visar senaste rapporterade deploymentstatus per dator och fas (PreCache/IPU) inom vald Scope-collection. Rapporten skiljer mellan TS-fel, avvisad deployment, avbruten körning, gammal pågående status och tilldelad dator utan rapport. Datorer som aldrig tilldelats en vald deployment klassas inte som misslyckade.

Varje dator kan ha två rader, en per fas. KPI:n räknar unika datorer separat från antal felrader. Status väljs före felfiltreringen: ett äldre ringfel ska inte vinna över en senare lyckad Retry. Status med exakt samma senaste tid markeras för granskning. En ny väntande deployment kan också vara senaste rapporterade tillstånd; detta är ingen fullständig journal över varje försök.

**IPU25H2_TS_Detail.rdl** öppnas via datornamnet och visar steghistorik, grupp, åtgärd, statusmeddelande, returvärde i decimal/hex samt ActionOutput. Alla rapporterade steg visas. Returvärde != 0 betyder inte automatiskt fel, till exempel 3010 eller 0xC1900210 vid kompatibilitetsskanning. Senast rapporterat steg är inte alltid felsteget eller grundorsaken.

**Inventerade kontroller** ligger i en separat tabell med egen kontrolltid och revision. Där kan CompatStatus, ReadinessStatus, PreCacheStatus, efterkontroll och en explicit rollbackmarkör visas. Den delen är avsiktligt tom tills mappingen är gjord; frånvaro presenteras inte som godkänt resultat.

## Filer

| Fil | Innehåll |
|---|---|
| IPU25H2_Feloversikt.rdl | Huvudrapport med parametrar, KPI, statuslista och inventeringsdel. |
| IPU25H2_TS_Detail.rdl | Detaljrapport för en dator och en deployment. |
| sql/Main.sql | Huvudrapportens exakta NativeStatus-fråga. |
| sql/StepHistory.sql | Detaljrapportens exakta fråga. |
| sql/Inventory.sql | Körbar tom adapter plus åtkomstbegränsad inventeringsfråga. |
| sql/InventoryAdapter.template.sql | Ej körklar mall för er egen inventeringsvy. |
| sql/CheckSchema.sql | Läsbar kontroll av nödvändiga vyer, kolumner och RBAC-funktioner. |
| Design.html | Statisk designskiss med tydligt märkta demonstrationsdata. |
| VALIDATION.json | Resultat från den lokala struktur- och logikverifieringen. |

## Installation

1. Använd en ConfigMgr-integrerad Reporting Services Point och dess befintliga delade SQL-datakälla mot `CM_<sitecode>`. Att enbart ha en fristående SSRS-installation räcker inte för paketets ConfigMgr-RBAC/SrsResources-koppling.
2. Kör `sql/CheckSchema.sql` som en läsfråga i sitedatabasen. Första resultatet ska sakna rader. Kontrollera att funktionerna finns och att rätt kolumner visas. Avbryt importen och anpassa frågorna om er version saknar en nödvändig kolumn.
3. Öppna båda RDL-filerna i Report Builder. Ändra datakällan `ConfigMgr` till er faktiska delade datakälla. Platshållaren `/ConfigMgr_REPLACE/REPLACE_WITH_SHARED_DATASOURCE` ska ersättas via datakällans egenskaper.
4. Behåll den vanliga ConfigMgr-kedjan `UserTokenSIDs -> AdminID -> UserSIDs` och `SrsResources, culture=neutral`. Vyerna för status och steg kopplas till behörighetsfiltrerade datorer, collections och deploymenter. Använd inte `disabled` som genväg för UserSIDs. Kontrollera med en begränsad användare före publicering.
5. Publicera båda rapporterna i samma rapportmapp. Behåll detaljrapportens namn **IPU25H2_TS_Detail** så att drillthrough fungerar.
6. Välj projektets fasta **IPU25H2-Scope**, inte Source eller en deploymentcollection. Då finns uppgraderade och återställda datorer kvar i rapporturvalet.
7. Välj samtliga relevanta IPU-deploymenter: pilot, ring 0-9 och Retry. Välj PreCache separat. Samma deployment får inte anges som båda faserna. Använd `(ingen)` för en fas som inte ska tas med. Om båda är `(ingen)` blir urvalet tomt.
8. Kör först med **Endast problemrader = Nej** och jämför kända datorer med Monitoring > Deployments och klientlogg. Testa sedan problemfiltret.

SQL-filerna med `IN (@IPUDeploymentIDs)` och `IN (@PreCacheDeploymentIDs)` är datasetfrågor för SSRS-parametrar med flera värden. De kan inte testas i SSMS genom att lägga alla ID:n i en enda kommaseparerad sträng. Använd separata parametrar/literaler i ett test, eller kör i Report Builder.

## Parametrar

| Parameter | Betydelse |
|---|---|
| CollectionID | Fast projekt-Scope. Listan begränsas av ConfigMgr-RBAC. |
| IPUDeploymentIDs | En eller flera exakta deployment-ID:n, inklusive Retry. |
| PreCacheDeploymentIDs | PreCache-deploymenter, separat från IPU. |
| Ring | Alla, slutsiffra 0-9 eller datorer utan slutsiffra. Pilot visas efter datornamnets siffra; ett separat pilotfilter ingår inte. |
| OnlyIssues | Filtrerar native statusdelen. Pågående aktuella körningar och TS-framgång döljs när Ja väljs. |
| StaleHours | Gräns för uppföljning av gammal väntande/pågående status, standard 24 timmar. Detta bevisar inte att TS fastnat. |
| InventoryMaxAgeHours | Åldersmarkering för PreCache-inventering, standard 168 timmar. Filtrerar inte bort historiska resultat. |
| DaysBack | Steghistorikens tidsfönster, standard 90 dagar. Öka om det aktuella felet är äldre. |

Native SQL-tider antas vara UTC. Bekräfta representationen i er miljö. Rapportens skapandetid visas i SSRS-serverns tidszon och märks separat i sidfoten. Inventeringsadaptern måste ge UTC-tider, inte lokala tidssträngar. Om flera deploymenter har exakt samma senaste rapporttid visas granskningsstatus, inte en godtycklig grön framgång.

## Koppla CompatStatus och ReadinessStatus

Deras faktiska lagringsplats och värden är ännu inte kända. Inga påhittade SQL-vyer används av standardrapporten.

1. Kör sista frågan i `CheckSchema.sql` för att hitta SQL-kolumner som innehåller CompatStatus/ReadinessStatus. Matcha mot Resource Explorer och er PreCache-implementation. WQL-klassen `SMS_G_System_*` är inte namnet på SQL-vyn; SQL använder ofta `v_GS_*` och fältsuffix `0`.
2. Fyll i `InventoryAdapter.template.sql`. Mappa faktiska värden till de dokumenterade textvärdena. För CompatStatus ska Windows Setups scan-only-kod hanteras som avsett; för ReadinessStatus måste de aktiverade kontrollerna ha körts. Bevara originalkoden i CompatExitCode.
3. Leverera en aktuell, sammanhängande rad per ResourceID och målversion. Fälten ska komma från rätt körning/revision. Rapporten markerar dubbletter men kan inte återskapa vilken rad som var korrekt.
4. Byt SELECT-blocket mellan `ADAPTER_BEGIN` och `ADAPTER_END` i `sql/Inventory.sql`. Ändra samma block i huvudrapportens dataset **InventoryStatus** i Report Builder. SQL-filerna är inte externa live-källor för RDL-filerna; ändringar i en `.sql` uppdaterar inte automatiskt RDL.
5. Behåll output-alias och datatyper. Okända fält ska vara typade NULL. Rollback får bara vara Ja om ni faktiskt har sparat en rollbackmarkör. Ett gammalt OS efter ett fel räcker inte för att hävda rollback.
6. Visa efterkontrollens egen tid i IPUResultTime. Jämför dessa tidsstämplar med native statusdelen innan någon automatisk åtgärd tas. Tabellen är inventerad historik/ögonblicksbild, inte en global senaste-försöket-klassning.

Inventeringstabellen visar alla mappade statusar inom Scope/ring även när OnlyIssues = Ja. En äldre blockering kan finnas kvar efter en senare lyckad körning; den blandas därför inte in i native fel-KPI:n. Ålder och revision visas. Bygg inte automatisk Retry direkt från denna tabell utan ett tillförlitligt AttemptId/RunId och jämförbar slutstatus.

## Begränsningar och verifiering

- SQL och rapporter har inte körts mot er databas eller SSRS-server. Paketet är ett implementationunderlag med miljöspecifika anslutningar som måste verifieras.
- RDL-struktur och lokal statuslogik valideras i VALIDATION.json. XML/XSD-validering ersätter inte körning av SSRS-uttryck, SQL-bindning eller visuell granskning i Report Builder.
- Rapporten väljer senaste rapporterade deploymentstatus per fas, inte en exakt försöksjournal. Samma deployment kan ha körts flera gånger. Native status kan vara fördröjd, och äldre steghistorik kan ha rensats enligt sitens retention.
- Ingen datumgräns används innan native senaste-status väljs. En nyare lyckad Retry ska därför inte falla bort och lämna ett äldre fel som aktuellt.
- Steghistoriken är begränsad till 5 000 senaste rader och ActionOutput till 4 000 tecken per rad. Använd klientloggar för full historik.
- Ett TS-fel tillsammans med inventerad build 26200 är ett uppgraderingsfel med OS redan installerat, inte automatiskt en misslyckad OS-installation. Utred eftersteg och riktad reparation.
- Scope-medlemskap och OS-build är inte realtidsdata. Datornamnets sista tecken används för ring; ett namnbyte kan ändra ring.
- Core-queryn använder dokumenterade vyer plus ConfigMgrs RBAC-funktioner. Inga tabeller, vyer eller procedurer ska skapas i ConfigMgr-databasen för att använda paketet.

Testa minst: gammalt fel + senare lyckad Retry; okänd native status; 25H2 installerat men TS-fel; aktuell kontra gammal Running; avvisad deployment; dubblettid; 3010; godkänd kompatibilitetsskanning; saknade anpassade fält; begränsad rapportanvändare.

## Källor

- [ConfigMgr OSD SQL views](https://learn.microsoft.com/en-us/intune/configmgr/develop/core/understand/sqlviews/operating-system-deployment-views-configuration-manager)
- [ConfigMgr application management SQL views](https://learn.microsoft.com/en-us/intune/configmgr/develop/core/understand/sqlviews/application-management-views-configuration-manager)
- [Microsofts exempelrapport med RBAC](https://learn.microsoft.com/en-us/intune/configmgr/develop/core/understand/sqlviews/evaluation-computer-information-report-configuration-manager)
- [Microsoft: skapa en RBAC-rapport](https://techcommunity.microsoft.com/blog/coreinfrastructureandsecurityblog/how-to-create-a-rba-capable-report-for-configmgr-r2/884624)
- [Statuskategorier: 11 Failed, 13 Succeeded](https://learn.microsoft.com/en-us/intune/configmgr/develop/reference/core/servers/configure/sms_advertisementstatusinformation-server-wmi-class)
- [TS-variabler och kompatibilitetsresultat](https://learn.microsoft.com/en-us/intune/configmgr/osd/understand/task-sequence-variables)
- [RDL 2016-schema](https://learn.microsoft.com/en-us/openspecs/sql_server_protocols/ms-rdl/52ce3983-2bfc-4e72-9359-42aaf5fe4509)
